SELINA LOVE WEBSITE — FIXED STATIC SITE

Included:
- index.html
- selina-song.mp3 (the supplied “Don't Let Go - Zavyre - BagOnly” song)

The song loops and starts when the visitor taps “Play our song”.
The audio file must stay beside index.html.

To publish on Render:
1. Open https://dashboard.render.com/static/srv-dbf6s667bikc73cdbkbg
2. Open the connected GitHub repository and replace its index.html with this index.html.
3. Upload selina-song.mp3 into the repository root (same folder as index.html).
4. Commit both files to the main branch.
5. Wait for Render's automatic deploy, then open https://selina-love-website.onrender.com

Render settings for a plain static site:
- Build command: echo 'Static site - no build step required'
- Publish directory: .
